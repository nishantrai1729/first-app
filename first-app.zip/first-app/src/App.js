import React, { Component } from "react";
import "./App.css";

class App extends Component {
  state = {
    value: 1000,
    id: 0,
  };

  startInc = () => {
    let val = setInterval(() => {
      let money = this.state.value + 1;
      this.setState({ ...this.state, value: money });
    }, 1000);
    this.setState({ ...this.state, id: val });
  };

  stopInc = () => {
    clearInterval(this.state.id);
  };

  render() {
    return (
      <div className="Main-Body">
        <div className="Body-Wrapper">
          <div className="Value-Container">${this.state.value}</div>
          <div className="Button-Container">
            <button className="Start-Increment" onClick={this.startInc}>
              Start
            </button>
            <button className="Stop-Increment" onClick={this.stopInc}>
              Stop
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
